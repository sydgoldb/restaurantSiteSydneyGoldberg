function validateItems() {
    clearErrors();
    var phone = document.forms["whatsUp"]["whatsUp"].value;
 
    if (phone == "" || isNaN(Number)) {
        alert("Please enter a numerical value for this field.");
        document.forms["whatsUp"]["phone"]
           .parentElement.className = "form-group has-error";
        document.forms["whatsUp"]["phone"].focus();
        return false;
    }
  